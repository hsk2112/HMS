insert into Patient(address,contact_number,disease,email_id,gender,name) 
values('South Park',9700123456,'cold','phsk@gmail.com','Male','Phsk');
insert into Patient(address,contact_number,disease,email_id,gender,name) 
values('GulmoharPark',9700123457,'cough','phsk12@gmail.com','Male','Phks');
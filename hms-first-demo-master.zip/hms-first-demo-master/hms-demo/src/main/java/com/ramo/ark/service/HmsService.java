package com.ramo.ark.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ramo.ark.dao.impl.PatientDAOImpl;
import com.ramo.ark.model.Patient;

@Service
public class HmsService {

	@Autowired
	PatientDAOImpl patientDao;

	List<Patient> listPatients;

	// Patients Methods
	public List<Patient> showAllPatients() {
		listPatients = patientDao.allPatients();
		return listPatients;
	}

	public List<Map<String, Object>> searchPatientByName(String patientName) {
		return patientDao.searchPatientByName(patientName);
	}

	public Patient searchPatientById(long id) {
		return patientDao.searchPatientById(id);
	}

	public Patient createPatient(Patient patient) {
		return patientDao.createPatient(patient);
	}

	public void updatePatient(Patient patient) {
		patientDao.updatePatient(patient);
	}

	public void deletePatient(long id) {
		patientDao.deletePatient(id);
	}

}

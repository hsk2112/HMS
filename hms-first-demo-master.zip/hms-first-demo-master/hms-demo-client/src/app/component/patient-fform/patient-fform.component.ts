import { Component, OnInit } from '@angular/core';
import { Patient } from 'src/app/model/patient';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientService } from 'src/app/service/patient.service';

@Component({
  selector: 'app-patient-fform',
  templateUrl: './patient-fform.component.html',
  styleUrls: ['./patient-fform.component.css']
})
export class PatientFformComponent implements OnInit {

  patient: Patient;

  constructor(private route: ActivatedRoute, private router: Router, private patientService: PatientService) {
    this.patient = new Patient();
  }

  onSubmit() {
    this.patientService.save(this.patient).subscribe(result => this.gotoPatientList());
  }
  gotoPatientList() {
    this.router.navigate(['/patients']);
  }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientFformComponent } from './patient-fform.component';

describe('PatientFformComponent', () => {
  let component: PatientFformComponent;
  let fixture: ComponentFixture<PatientFformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientFformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientFformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientFformComponent } from './component/patient-fform/patient-fform.component';
import { PatientListComponent } from './component/patient-list/patient-list.component';


const routes: Routes = [
  { path: 'patients', component: PatientListComponent},
  { path: 'patients/addPatient', component: PatientFformComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

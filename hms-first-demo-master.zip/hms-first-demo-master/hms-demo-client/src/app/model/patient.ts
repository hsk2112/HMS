export class Patient {

    id: string;
    name: string;
    address: string;
    gender: string;
    disease: string;
    emailId: string;
    contactNumber: string;
}
